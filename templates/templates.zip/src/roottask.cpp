#include "roottask.h"

RootTask::RootTask()
    : ITask("RootTask")
{
}

void RootTask::prepare_()
{
    // Called on first frame
}

void RootTask::calc_()
{
    // Called on every frame till task termination
}

void RootTask::exit_()
{
    // Called on task termination
}
